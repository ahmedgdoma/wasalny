// Global user functions
